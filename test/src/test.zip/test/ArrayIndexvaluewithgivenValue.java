package test;

public class ArrayIndexvaluewithgivenValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	int	a[] = {15, 2, 45, 12, 7};
	for(int i=0;i<a.length;i++)
	{
		if(a[i]==i+1)
		{
			System.out.println(a[i]);
		}
	}

	}

}
